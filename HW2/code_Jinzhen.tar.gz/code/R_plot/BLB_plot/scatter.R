beta <- read.table("final/blb_lin_reg_data_s5_r50_SE.txt",sep="\n",header=T)
n=1:1000
plot(beta, col="blue",pch=19, cex=.2, xlab="n",ylab="beta_n")  