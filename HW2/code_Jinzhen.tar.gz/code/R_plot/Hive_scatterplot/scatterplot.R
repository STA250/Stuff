
# Make 2D Histogram:

avgf <- read.table("group_avg.txt",sep="\t",header=F)
varf <- read.table("group_var.txt",sep="\t",header=F)

avg <- avgf[,2]
var <- varf[,2]
plot(avg, var, col="blue",pch=19, cex=.4, xlab="average",ylab="variance")  