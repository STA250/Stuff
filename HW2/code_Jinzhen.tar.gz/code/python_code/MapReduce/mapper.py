#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Sat Nov  9 22:59:22 2013

@author: jinzhen
"""


import sys

def trunc(f, n):
    '''Truncates/pads a float f to n decimal places without rounding'''
    if f>0 or f==0:
        return ('%.*f' % (n + 1, f))[:-1]
        
    # if the float f is negative, minus 0.1
    else:
        return ('%.*f' % (n + 1, f-0.1))[:-1]
    
# input comes from STDIN (standard input)
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()
    # split the line into words
    words = line.split()
    x=trunc(float(words[0]),1)
    y=trunc(float(words[1]),1)
    # increase counters
    print '%s\,%s\t%s' % (x,y,1)

