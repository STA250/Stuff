#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Created on Sun Nov 10 23:04:22 2013

@author: jinzhen
"""

from operator import itemgetter
import sys
import csv

current_x = None
current_y = None
current_count = 0
x = None
y = None
data=None
with open('./MapRout.csv', 'a') as csvfile:
    output = csv.writer(csvfile, delimiter='\t',dialect='excel')
    for line in sys.stdin:
        
        line = line.strip()
        
        data, count = line.split('\t', 1)
        x,y=data.split('\,',1)
        
        
        
        try:
            count = int(count)
        except ValueError:
            continue
        if current_x==x and current_y == y:
            current_count += count
        else:
            if current_x and current_y:
                print '%s\t%s\t%s\t%s\t%s' % (current_x, float(current_x)+0.1, current_y, float(current_y)+0.1, current_count)
                output.writerow([str(current_x),str(float(current_x)+0.1),str(current_y),str(float(current_y)+0.1), str(current_count)])
            current_count = count
            current_x, current_y = x, y
    if current_x==x and current_y == y:
        print '%s\t%s\t%s\t%s\t%s' % (current_x, float(current_x)+0.1, current_y, float(current_y)+0.1, current_count)
        output.writerow([str(current_x), str(float(current_x)+0.1), str(current_y), str(float(current_y)+0.1), str(current_count)])
csvfile.closed